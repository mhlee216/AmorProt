#!/usr/bin/env python
# coding: utf-8

from .AmorProt import AmorProt

__all__ = ("AmorProt")
