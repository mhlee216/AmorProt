from .AmorProt import AmorProt

__all__ = ("AmorProt")
